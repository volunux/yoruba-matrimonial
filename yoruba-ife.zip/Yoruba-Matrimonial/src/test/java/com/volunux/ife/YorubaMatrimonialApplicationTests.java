package com.volunux.ife;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YorubaMatrimonialApplicationTests {

	@Test
	void contextLoads() {
	}

}
